Hooks.once('diceSoNiceReady', (dice3d) => {

//////////////////////////////////////////
//                aburame                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "aburame", name: "🍥 Aburame"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/aburame/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "aburame"
    });

//////////////////////////////////////////
//                akimichi                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "akimichi", name: "🍥 Akimichi"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akimichi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "akimichi"
    });

//////////////////////////////////////////
//                hatake                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "hatake", name: "🍥 Hatake"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hatake/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hatake"
    });


//////////////////////////////////////////
//                hebi                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "hebi", name: "🍥 Hebi"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hebi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hebi"
    });


//////////////////////////////////////////
//                hosigaki              //
//////////////////////////////////////////

    dice3d.addSystem({id: "hosigaki", name: "🍥 Hosigaki"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hosigaki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hosigaki"
    });

//////////////////////////////////////////
//                hozuki                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "hozuki", name: "🍥 Hozuki"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hozuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hozuki"
    });

//////////////////////////////////////////
//                hyuga                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "hyuga", name: "🍥 Hyuga"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/hyuga/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "hyuga"
    });

//////////////////////////////////////////
//                inuzuka                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "inuzuka", name: "🍥 Inuzuka"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/inuzuka/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "inuzuka"
    });


////////////////////////////////////////////
//                KURAMA                  //
///////////////////////////////////////////

    dice3d.addSystem({id: "kurama", name: "🍥 Kurama"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kurama/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kurama"
    });
	
	
//////////////////////////////////////////
//                kuru                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "kuru", name: "🍥 Kuru"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kuru/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kuru"
    });


//////////////////////////////////////////
//                nara                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "nara", name: "🍥 Nara"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/nara/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "nara"
    });
	
	
//////////////////////////////////////////
//                ryu                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "ryu", name: "🍥 Ryu"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ryu/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ryu"
    });


//////////////////////////////////////////
//                sarutobi                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "sarutobi", name: "🍥 Sarutobi"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sarutobi/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "sarutobi"
    });

//////////////////////////////////////////
//                senju                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "senju", name: "🍥 Senju"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senju/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "senju"
    });

//////////////////////////////////////////
//                tsuchigumo                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "tsuchigumo", name: "🍥 Tsuchigumo"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tsuchigumo/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "tsuchigumo"
    });


//////////////////////////////////////////
//               UCHIHA                 //
//////////////////////////////////////////

    dice3d.addSystem({id: "uchiha", name: "🍥 Uchiha"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uchiha/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "uchiha"
    });

//////////////////////////////////////////
//               uzumaki                //
//////////////////////////////////////////

    dice3d.addSystem({id: "uzumaki", name: "🍥 uzumaki"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/uzumaki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "uzumaki"
    });

//////////////////////////////////////////
//                yamanaka                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "yamanaka", name: "🍥 Yamanaka"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yamanaka/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yamanaka"
    });

//////////////////////////////////////////
//                YUKI                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "yuki", name: "🍥 Yuki ❄️"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yuki"
    });

//////////////////////////////////////////
//                bakuton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "bakuton", name: "🍥 Bakuton 💥"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/bakuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "bakuton"
    });

//////////////////////////////////////////
//                futton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "futton", name: "🍥 Futton ♨️"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/futton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "futton"
    });

//////////////////////////////////////////
//                jiton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "jiton", name: "🍥 Jiton 🧲"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jiton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "jiton"
    });

//////////////////////////////////////////
//                swift                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "swift", name: "🍥 Swift 💨"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/swift/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "swift"
    });

//////////////////////////////////////////
//                Ranton                //
/////////////////////////////////////////

    dice3d.addSystem({id: "ranton", name: "🍥 Ranton ⛈️"}, "preferred");
    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ranton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ranton"
    });

//////////////////////////////////////////
//                mokuton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "mokuton", name: "🍥 mokuton 🌳"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/mokuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "mokuton"
    });


//////////////////////////////////////////
//                shakuton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "shakuton", name: "🍥 Shakuton 🔥"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shakuton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shakuton"
    });

//////////////////////////////////////////
//                shoton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "shoton", name: "🍥 shoton 💎"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shoton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shoton"
    });


//////////////////////////////////////////
//                yoton                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "yoton", name: "🍥 yoton 🌋"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/yoton/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "yoton"
    });
	
	
//////////////////////////////////////////
//                earthrelease                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "earthrelease", name: "🍥 Earth"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/earthrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "earthrelease"
    });

	
//////////////////////////////////////////
//                fire                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "fire", name: "🍥 Fire"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/fire/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "fire"
    });
	


//////////////////////////////////////////
//                lightning                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "lightning", name: "🍥 lightning"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/lightning/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "lightning"
    });


//////////////////////////////////////////
//                waterrelease                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "waterrelease", name: "🍥 Water"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/waterrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "waterrelease"
    });


//////////////////////////////////////////
//                windrelease                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "windrelease", name: "🍥 Wind"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/windrelease/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "windrelease"
    });


/////////////////////////////////////////////
//                Rinnegan                 //
////////////////////////////////////////////

    dice3d.addSystem({id: "rinnegan", name: "🍥 Rinnegan"}, "preferred");
    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/rinnegan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "rinnegan"
    });

/////////////////////////////////////////////
//                Sharingan                //
////////////////////////////////////////////

    dice3d.addSystem({id: "sharingan", name: "🍥 Sharingan"}, "preferred");
    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/sharingan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "sharingan"
    });

/////////////////////////////////////////////
//               Byakugan                 //
////////////////////////////////////////////

    dice3d.addSystem({id: "byakugan", name: "🍥 Byakugan"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/byakugan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "byakugan"
    });
	
	

//////////////////////////////////////////
//                tenseigan                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "tenseigan", name: "🍥 Tenseigan"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/tenseigan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "tenseigan"
    });



//////////////////////////////////////////
//                ksm                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "ksm", name: "🍥 Kurama Sage Mode"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/ksm/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "ksm"
    });



//////////////////////////////////////////
//                jigen                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "jigen", name: "🍥 Jigen Dojutsu"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jigen/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "jigen"
    });



//////////////////////////////////////////
//                teiogan                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "teiogan", name: "🍥 Teiogan"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/teiogan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "teiogan"
    });

//////////////////////////////////////////
//                senrigan                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "senrigan", name: "🍥 Senrigan"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });
	

//////////////////////////////////////////
//                king                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "king", name: "🍥 King's mangekyou"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/king/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "king"
    });


    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/senrigan/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "senrigan"
    });


/////////////////////////////////////////////
//                Shuriken                //
////////////////////////////////////////////

    dice3d.addSystem({id: "shuriken", name: "🍥 Shuriken"}, "preferred");
    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/shuriken/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "shuriken"
    });

//////////////////////////////////////////
//                Konoha                //
/////////////////////////////////////////

    dice3d.addSystem({id: "konoha", name: "🍥 Konoha"}, "preferred");
    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/konoha/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "konoha"
    });
	
	
//////////////////////////////////////////
//                iwa                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "iwa", name: "🍥 Iwa"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/iwa/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "iwa"
    });

	
//////////////////////////////////////////
//                suna                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "suna", name: "🍥 Suna"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/suna/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "suna"
    });


//////////////////////////////////////////
//                kiri                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "kiri", name: "🍥 Kiri"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kiri/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kiri"
    });


//////////////////////////////////////////
//                kumo                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "kumo", name: "🍥 Kumo"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/kumo/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "kumo"
    });

	
//////////////////////////////////////////
//                Jashin                //
/////////////////////////////////////////

    dice3d.addSystem({id: "jashin", name: "🍥 Jashin"}, "preferred");
    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/jashin/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "jashin"
    });
	


//////////////////////////////////////////
//                akatsuki                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "akatsuki", name: "🍥 akatsuki"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/akatsuki/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "akatsuki"
    });



//////////////////////////////////////////
//                police                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "police", name: "🍥 Uchiha Police"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/police/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "police"
    });


//////////////////////////////////////////
//                anbu                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "anbu", name: "🍥 Anbu"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/anbu/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "anbu"
    });



//////////////////////////////////////////
//                eighttrigrams                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "eighttrigrams", name: "🍥 Eight Trigrams Seal"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/eighttrigrams/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "eighttrigrams"
    });


//////////////////////////////////////////
//                curse                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "curse", name: "🍥 Cursed Seal"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/curse/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "curse"
    });


//////////////////////////////////////////
//                naruto5e                  //
//////////////////////////////////////////

    dice3d.addSystem({id: "naruto5e", name: "🍥 Naruto 5e"}, "preferred");
    dice3d.addDicePreset({
        type: "d2",
        labels: [
          "1",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });

    dice3d.addDicePreset({
        type: "d4",
        labels: [
          "1","2","3",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });

    dice3d.addDicePreset({
        type: "d6",
        labels: [
          "1","2","3","4","5",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20.png"
        ],
        bumpMaps: [,,,,,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });

    dice3d.addDicePreset({
        type: "d8",
        labels: [
          "1","2","3","4","5","6","7",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });

    dice3d.addDicePreset({
        type: "d10",
        labels: [
          "1","2","3","4","5","6","7","8","9",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });

    dice3d.addDicePreset({
        type: "d12",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });

    dice3d.addDicePreset({
        type: "d20",
        labels: [
          "1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19",
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20-81020.png"
        ],
        bumpMaps: [,
          "modules/dice-so-nice-naruto5e-pack/textures/naruto5e/nat20_bump-81020.png"
        ],
        font:"Arcane Nine",
        system: "naruto5e"
    });


});